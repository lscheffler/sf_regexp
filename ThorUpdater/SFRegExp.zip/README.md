# SF RegExp

---
This folder holds the code and helper.   
Include this to your project to use SF RegExp.

In the PDM folder you will find the the code documentation.

- Do not include the PDM folder to your project.
- Do not include the .gitignore to your project.
